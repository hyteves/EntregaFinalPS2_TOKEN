// Felipe Damasceno - 42202817
// Hyandra Marjory - 42217954
// Nicole Previd - 42206774

package br.mackenzie.Projeto.user;

public record AuthenticationDTO(String login, String password) {
    
}
